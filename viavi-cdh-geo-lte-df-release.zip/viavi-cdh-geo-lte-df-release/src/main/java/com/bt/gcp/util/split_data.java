//package com.bt.gcp.util;
//
//import com.google.api.services.bigquery.model.TableFieldSchema;
//import com.google.api.services.bigquery.model.TableSchema;
////import static com.bt.gcp.constants.Constants.COLUMNS;
////import static com.bt.gcp.constants.Constants.D_TYPES;
//
//import java.lang.reflect.Array;
//import java.util.ArrayList;
//import java.util.Arrays;
//import java.util.List;
//
//public class split_data {
////    public static void main(String[] args) {
////        String data = "BT_GeoAnalytics_LTE_20220502_3993_BATCH.csv|920.63|161.49|25772C11|234301080126506|0.24|1|0.00|90625A11|2022/05/02 01:00:00|0.00|1|35132811|0.13|116|0.16|26|0.24|0.00|697800|5671700|0.00|0.24BT_GeoAnalytics_LTE_20220502_3993_BATCH.csv|920.63|161.49|25772C11|234301080126506|0.24|1|0.00|90625A11|2022/05/02 01:00:00|0.00|1|35132811|0.13|116|0.16|26|0.24|0.00|697800|5671700|0.00|0.24";
////        String[] values = data.split("\\|",-1);
////        for (int i = 0; i < values.length; i++) {
////            System.out.println(values[i]);
////            }
////        }
//    public static void main(String[] args) {
//        List<TableFieldSchema> fields = new ArrayList<>();
//        fields.add(constructTableFieldSchema("filename", "STRING"));
//        fields.add(constructTableFieldSchema("averagedownlinkthroughput", "FLOAT"));
//        fields.add(constructTableFieldSchema("averageuplinkthroughput", "FLOAT"));
//        fields.add(constructTableFieldSchema("endcellname", "STRING"));
//        fields.add(constructTableFieldSchema("maskedimsi", "STRING"));
//        fields.add(constructTableFieldSchema("minutesofuse", "FLOAT"));
//        fields.add(constructTableFieldSchema("numberofconnections", "INTEGER"));
//        fields.add(constructTableFieldSchema("pedestrianminutesofuse", "FLOAT"));
//        fields.add(constructTableFieldSchema("startcellname", "STRING"));
//        fields.add(constructTableFieldSchema("starttime", "TIMESTAMP"));
//        fields.add(constructTableFieldSchema("stationaryminutesofuse", "FLOAT"));
//        fields.add(constructTableFieldSchema("sv", "STRING"));
//        fields.add(constructTableFieldSchema("tac", "STRING"));
//        fields.add(constructTableFieldSchema("totaldownlinkdataduration", "FLOAT"));
//        fields.add(constructTableFieldSchema("totaldownlinkvolume", "INTEGER"));
//        fields.add(constructTableFieldSchema("totaluplinkdataduration", "FLOAT"));
//        fields.add(constructTableFieldSchema("totaluplinkvolume", "INTEGER"));
//        fields.add(constructTableFieldSchema("vehicularminutesofuse", "FLOAT"));
//        fields.add(constructTableFieldSchema("voiceminutesofuse", "FLOAT"));
//        fields.add(constructTableFieldSchema("xbin", "STRING"));
//        fields.add(constructTableFieldSchema("ybin", "STRING"));
//        fields.add(constructTableFieldSchema("indoorminutesofuse", "FLOAT"));
//        fields.add(constructTableFieldSchema("outdoorminutesofuse", "FLOAT"));
//        fields.add(constructTableFieldSchema("batch_num", "STRING"));
//
//        TableSchema tableSchema = new TableSchema().setFields(fields);
//        tableSchema.setFields(fields);
//
//        ArrayList<String> list = new ArrayList<>();
//        String[] cols =COLUMNS.split(",",-1);
//        list.addAll(Arrays.asList(cols) );
//        System.out.println(list);
//
//
//
//    }
//
//    private static TableFieldSchema constructTableFieldSchema(String name, String type) {
//        TableFieldSchema tableFieldSchema = new TableFieldSchema();
//        ArrayList<String> fields = new ArrayList<String>();
//
//        tableFieldSchema.setName(name);
//        tableFieldSchema.setType(type);
//        return tableFieldSchema;
//    }
//
//}
//
//
//
////import org.apache.beam.sdk.transforms.CombineFnBase;
////
////public class split_data implements CombineFnBase.GlobalCombineFn<InputT, Object, OutputT> {
////    public static int main(String[] args) {
////        int i = 0;
////        i++;
////        return i;
////    }
////
////    }