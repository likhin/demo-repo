package com.bt.gcp.options;

import org.apache.beam.runners.dataflow.options.DataflowPipelineOptions;
import org.apache.beam.sdk.options.Description;
import org.apache.beam.sdk.options.ValueProvider;

public interface ViaviOptions extends DataflowPipelineOptions {

    @Description("Source file path")
    ValueProvider<String> getSource();
    void setSource(ValueProvider<String> src);

    @Description("Source file path")
    ValueProvider<String> getFeedname();
    void setFeedname(ValueProvider<String> src);

    @Description("Batch number")
    ValueProvider<String> getBatchNum();
    void setBatchNum(ValueProvider<String> src);

    @Description("BQ Table Name")
    ValueProvider<String> getBqTableName();
    void setBqTableName(ValueProvider<String> src);

    @Description("BQ Error Table Name")
    ValueProvider<String> getBqErrorTableName();
    void setBqErrorTableName(ValueProvider<String> src);

}
