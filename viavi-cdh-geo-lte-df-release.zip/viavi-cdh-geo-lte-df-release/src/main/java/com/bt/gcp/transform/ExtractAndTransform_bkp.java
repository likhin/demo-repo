package com.bt.gcp.transform;

import com.bt.gcp.util.Util;
import com.google.api.services.bigquery.model.TableRow;
import org.apache.beam.sdk.options.ValueProvider;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.TupleTag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;

import static com.bt.gcp.constants.Constants.*;
import static java.lang.Boolean.FALSE;
import static java.lang.Boolean.TRUE;


public class ExtractAndTransform_bkp extends DoFn<String,TableRow> {
    private TupleTag<TableRow> validDataTag = new TupleTag<>("validDataTag");
    private TupleTag<TableRow> invalidDataTag =  new TupleTag<>("invalidDataTag");

    ArrayList<String> list;
    ArrayList<String> type;
    ValueProvider<String> batch_num;
    ValueProvider<String> feed_name;

    public ExtractAndTransform_bkp(ValueProvider<String> batchnumber, ValueProvider<String> feedname, ArrayList<String> list, ArrayList<String> type) {
        this.list=list;
        this.type=type;
        this.batch_num = batchnumber;
        this.feed_name = feedname;

        System.out.println(batch_num);
        System.out.println(feed_name);
        logger.info("Pipeline Options batch_num"+batch_num);
        logger.info("Pipeline Options batch_num"+feed_name);
    }

    private static final Logger logger = LoggerFactory.getLogger(ExtractAndTransform_bkp.class);
    @ProcessElement
    public void processElement(ProcessContext context,MultiOutputReceiver out) {
        try {

            String[] values = context.element().split("\\|", -1);
            System.out.println("Number of elements " + values.length);
            Util util = new Util();
            TableRow row = new TableRow();
            TableRow error_row = new TableRow();
            boolean validSchema = TRUE;
            boolean not_header_rec = TRUE;
            String errorMessage = null;


            ArrayList<Integer> req_field_list = new ArrayList<>();
            int colSize =0;


            if(feed_name.get().equals("geo")) {
                req_field_list = geo_req_field_l;
                colSize = geo_num_of_cols;
            }

            if (colSize != values.length) {
                validSchema = FALSE;
                errorMessage = "Column Index mismatch, Expected: " + colSize + ", Actual: " + values.length;
                logger.error("ERR_004_CDR_SCHEMA_MISMATCH");
            }
            else {
                int count = 0;
                int maskedimsi_idx = 0;
                for (int i = 0; i < colSize; i++) {

                    if(geo_skip_fields.contains(i)) {
                        System.out.println("entered skip for " + values[i]);
                        continue;
                    }


                    System.out.println("unskipped path");

                    String element = list.get(count);
                    String schemaType = type.get(count);
                    String elementVal = values[i];

                    if(values[0].equals("AverageDownlinkThroughput")) {
                        System.out.println("header removal path");
                        not_header_rec = FALSE;
                        break;
                    }

                    if(element.equals("maskedimsi")) {
                        maskedimsi_idx = i ;
                        System.out.println("masked imsi index path");
                    }
                    if (!validSchema && element.equals("tac") && (elementVal.length() == 0 ) && (values[maskedimsi_idx].length() != 15)) {
                        System.out.println("masked imsi and tac  path");
                        errorMessage = "Null value received for tac field and maskedimsi field is INVALID  ";
                        error_row.set(element,null);
                    }
                    else if(elementVal.length() == 0 && element.equals("sv"))
                    {
                        System.out.println("sv length val path");
                        error_row.set(element,null);
                    }
                    else if (!validSchema) {
                        if(elementVal.length() == 0 && element.equals("sv"))
                        {
                            System.out.println("not valid schema path");
                            error_row.set(element,null);
                        }
                        error_row.set(element,elementVal);
                    }
                    else if(req_field_list.contains(i) && (elementVal.length() == 0)) {
                        errorMessage = "Null value received for the core field  " + element + " : " + elementVal;
                        System.out.println("length val path");
                        validSchema = FALSE;
                        error_row.set(element, null);
                    }
                    else if(element.equals("maskedimsi") && ( elementVal.length() != 15))
                    {
                        validSchema = FALSE;
                        System.out.println("makedimsi length val path");
                        error_row.set(element,elementVal);
                        errorMessage = "Length of maskedimsi field is not 15";
                    }
                    else if(element.equals("maskedimsi") )
                    {
                        System.out.println("Entered new block " + elementVal);
                        try {
                            Long long_element= Long.parseLong(elementVal.trim());
                            row.set(element, elementVal.trim());

                        }
                        catch(Exception e){
                            errorMessage = "Integer value is invalid " + element + " : " + elementVal;
                            validSchema = FALSE;
                            error_row.set(element,null);

                        }
                    }
                    else if (schemaType.equals("INTEGER")) try {
                        System.out.println("integer val path");
                        row.set(element, Integer.parseInt(elementVal));
                        error_row.set(element,elementVal);
                    }
                    catch(Exception e){
                        errorMessage = "Integer value is invalid " + element + " : " + elementVal;
                        validSchema = FALSE;
                        error_row.set(element,elementVal);
                    }
                    else if (schemaType.equals("FLOAT")) try {
                        System.out.println("float val path");
                        row.set(element,Float.parseFloat(elementVal));
                        error_row.set(element,elementVal);

                    }
                    catch(Exception e){
                        errorMessage = "Float value is invalid " + element + " : " + elementVal;
                        validSchema = FALSE;
                        error_row.set(element,elementVal);

                    }
                    else if (elementVal.isEmpty() || elementVal.toUpperCase() == "\\N" ||elementVal.equalsIgnoreCase("NULL")){
                        row.set(element, null);
                        error_row.set(element,null);

                    }
                    else if(elementVal.equals(" ") || elementVal.equals(""))
                    {
                        //validSchema = FALSE;
                        System.out.println("null val path");
                        row.set(element,null);
                        error_row.set(element,null);
                    }
                    else {
                        System.out.println("everything else path");
                        System.out.println(element);
                        System.out.println(elementVal);
                        row.set(element, elementVal);
                        error_row.set(element,elementVal);
                    }
                    System.out.println("count is being incremented");
                    count++;
                }
            }

            if (validSchema && not_header_rec) {
                System.out.println("final  val schma  path");
                row.set("batch_num",batch_num.get());
                out.get(validDataTag).output(row);
            }
            else if ((!validSchema) && not_header_rec){

                error_row.set("batch_num", batch_num.get());
                error_row.set("error_reason", errorMessage);
                error_row.set("load_datetime", util.getCurrentDateTime());
                logger.error("Error Record found:" + "errorDescription: " + errorMessage + "error_record: " + context.element());
                out.get(invalidDataTag).output(error_row);
            }
            else {
                System.out.println("Header record skipped");
            }

        }
        catch (Exception e) {
            logger.error("ERR_001_CDR_DF_FAILURE");
            logger.error("Error when parsing element to schema");
            logger.error(e.getMessage());
        }
    }
}
