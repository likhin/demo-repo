package com.bt.gcp.util;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Util {
    public String getDateTime(String value) {
        String date=value.substring(6,8);
        String month=value.substring(4,6);
        String year=value.substring(0,4);
        String hour=value.substring(8,10);
        String min=value.substring(10,12);
        String sec=value.substring(12,14);
        String bqdatetime=year+"-"+month+"-"+date+" "+hour+":"+min+":"+sec;
        return bqdatetime;
    }

    public String getDate(String value) {
        String date=value.substring(6,8);
        String month=value.substring(4,6);
        String year=value.substring(0,4);
        String bqdate=year+"-"+month+"-"+date;
        return bqdate;
    }

    public String getTime(String value) {
        String hour=value.substring(8,10);
        String min=value.substring(10,12);
        String sec=value.substring(12,14);
        String bqtime=hour+":"+min+":"+sec;
        return bqtime;
    }

    public String getCurrentDateTime() {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        LocalDateTime now = LocalDateTime.now();
        String dt_tm = now.format(dtf);
        return dt_tm;
    }

    public boolean longFieldValidation(String val){

        try {
            Long long_element= Long.parseLong(val.trim());

            return true;

        }
        catch (Exception e){
            return false;
        }
    }

    public boolean intFieldValidation(String val){

        try {
            Integer int_element= Integer.parseInt(val);

            return true;

        }
        catch (Exception e){
            return false;
        }
    }


    public boolean floatFieldValidation(String val){

        try {
            Float int_element= Float.parseFloat(val);
            return true;
        }
        catch (Exception e){
            return false;
        }
    }

    public boolean nullValidation(String elementVal){

        if ( elementVal.isEmpty() || elementVal.toUpperCase() == "\\N" ||elementVal.equalsIgnoreCase("NULL") || elementVal.equals(" ") || elementVal.matches("^\"{2}$")){
            return true;
        }else {
            return false;
        }
    }
}
