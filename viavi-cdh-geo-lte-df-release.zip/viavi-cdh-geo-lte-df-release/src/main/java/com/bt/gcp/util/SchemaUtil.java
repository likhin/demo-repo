package com.bt.gcp.util;

import com.google.api.services.bigquery.model.TableFieldSchema;
import com.google.api.services.bigquery.model.TableSchema;
import com.google.cloud.storage.Blob;
import com.google.cloud.storage.Storage;
import com.google.cloud.storage.StorageOptions;
import org.apache.beam.sdk.options.ValueProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

public class SchemaUtil {
    private static final Logger LOG = LoggerFactory.getLogger(SchemaUtil.class);

    public TableSchema getSchema_geo(){
        List<TableFieldSchema> fields = new ArrayList<>();
        //fields.add(constructTableFieldSchema("filename", "STRING"));
        fields.add(constructTableFieldSchema("averagedownlinkthroughput", "FLOAT"));
        fields.add(constructTableFieldSchema("averageuplinkthroughput", "FLOAT"));
        fields.add(constructTableFieldSchema("endcellname", "STRING"));
        fields.add(constructTableFieldSchema("maskedimsi", "INTEGER"));
        fields.add(constructTableFieldSchema("minutesofuse", "FLOAT"));
        fields.add(constructTableFieldSchema("numberofconnections", "INTEGER"));
        fields.add(constructTableFieldSchema("pedestrianminutesofuse", "FLOAT"));
        fields.add(constructTableFieldSchema("startcellname", "STRING"));
        fields.add(constructTableFieldSchema("starttime", "TIMESTAMP"));
        fields.add(constructTableFieldSchema("stationaryminutesofuse", "FLOAT"));
        fields.add(constructTableFieldSchema("sv", "STRING"));
        fields.add(constructTableFieldSchema("tac", "STRING"));
        fields.add(constructTableFieldSchema("totaldownlinkdataduration", "FLOAT"));
        fields.add(constructTableFieldSchema("totaldownlinkvolume", "INTEGER"));
        fields.add(constructTableFieldSchema("totaluplinkdataduration", "FLOAT"));
        fields.add(constructTableFieldSchema("totaluplinkvolume", "INTEGER"));
        fields.add(constructTableFieldSchema("vehicularminutesofuse", "FLOAT"));
        fields.add(constructTableFieldSchema("voiceminutesofuse", "FLOAT"));
        fields.add(constructTableFieldSchema("xbin", "STRING"));
        fields.add(constructTableFieldSchema("ybin", "STRING"));
        fields.add(constructTableFieldSchema("indoorminutesofuse", "FLOAT"));
        fields.add(constructTableFieldSchema("outdoorminutesofuse", "FLOAT"));
        fields.add(constructTableFieldSchema("batch_num", "STRING"));

        TableSchema tableSchema = new TableSchema().setFields(fields);
        tableSchema.setFields(fields);
        return tableSchema;

    }

    public TableSchema getSchema_geo_corr(){
        List<TableFieldSchema> fields = new ArrayList<>();
        //fields.add(constructTableFieldSchema("filename", "STRING"));
        fields.add(constructTableFieldSchema("averagedownlinkthroughput", "FLOAT"));
        fields.add(constructTableFieldSchema("averageuplinkthroughput", "FLOAT"));
        fields.add(constructTableFieldSchema("endcellname", "STRING"));
        fields.add(constructTableFieldSchema("maskedimsi", "INTEGER"));
        fields.add(constructTableFieldSchema("minutesofuse", "FLOAT"));
        fields.add(constructTableFieldSchema("numberofconnections", "INTEGER"));
        fields.add(constructTableFieldSchema("pedestrianminutesofuse", "FLOAT"));
        fields.add(constructTableFieldSchema("startcellname", "STRING"));
        fields.add(constructTableFieldSchema("starttime", "TIMESTAMP"));
        fields.add(constructTableFieldSchema("stationaryminutesofuse", "FLOAT"));
        fields.add(constructTableFieldSchema("sv", "STRING"));
        fields.add(constructTableFieldSchema("tac", "STRING"));
        fields.add(constructTableFieldSchema("totaldownlinkdataduration", "FLOAT"));
        fields.add(constructTableFieldSchema("totaldownlinkvolume", "INTEGER"));
        fields.add(constructTableFieldSchema("totaluplinkdataduration", "FLOAT"));
        fields.add(constructTableFieldSchema("totaluplinkvolume", "INTEGER"));
        fields.add(constructTableFieldSchema("vehicularminutesofuse", "FLOAT"));
        fields.add(constructTableFieldSchema("voiceminutesofuse", "FLOAT"));
        fields.add(constructTableFieldSchema("xbin", "STRING"));
        fields.add(constructTableFieldSchema("ybin", "STRING"));
        fields.add(constructTableFieldSchema("indoorminutesofuse", "FLOAT"));
        fields.add(constructTableFieldSchema("outdoorminutesofuse", "FLOAT"));
        fields.add(constructTableFieldSchema("batch_num", "STRING"));
        fields.add(constructTableFieldSchema("error_reason", "STRING"));
        fields.add(constructTableFieldSchema("load_datetime", "DATETIME"));

        TableSchema tableSchema = new TableSchema().setFields(fields);
        tableSchema.setFields(fields);
        return tableSchema;

    }

    private static TableFieldSchema constructTableFieldSchema(String name, String type) {
        TableFieldSchema tableFieldSchema = new TableFieldSchema();
        tableFieldSchema.setName(name);
        tableFieldSchema.setType(type);

        return tableFieldSchema;
    }
}



