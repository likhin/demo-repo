package com.bt.gcp.transform;

import com.bt.gcp.util.Util;
import com.google.api.services.bigquery.model.TableRow;
import org.apache.beam.sdk.options.ValueProvider;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.TupleTag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.ArrayList;
import static java.lang.Boolean.FALSE;
import static java.lang.Boolean.TRUE;
import static com.bt.gcp.constants.Constants.geo_num_of_cols;
import org.apache.beam.sdk.metrics.Counter;
import org.apache.beam.sdk.metrics.Metrics;


public class ExtractAndTransform extends DoFn<String,TableRow> {
    private TupleTag<TableRow> validDataTag = new TupleTag<>("validDataTag");
    private TupleTag<TableRow> invalidDataTag =  new TupleTag<>("invalidDataTag");

    private Counter validRecords = Metrics.counter(getClass(), "validrecord");
    private Counter errorRecord = Metrics.counter(getClass(), "errorrecord");
    private Counter AllRecord = Metrics.counter(getClass(), "allrecord");
    private Counter AllRecordwithoutHeader = Metrics.counter(getClass(), "allrecordwithoutheader");


    ValueProvider<String> batch_num;
    ValueProvider<String> feed_name;

    public ExtractAndTransform(ValueProvider<String> batchnumber,ValueProvider<String> feedname) {

        this.batch_num = batchnumber;
        this.feed_name = feedname;
        logger.info("Pipeline Options batch_num"+batch_num);
    }

    private static final Logger logger = LoggerFactory.getLogger(ExtractAndTransform.class);
    @ProcessElement
    public void processElement(ProcessContext context,MultiOutputReceiver out) {
        try {

            AllRecord.inc();

            String[] values = context.element().split("\\|", -1);
            Util util = new Util();
            TableRow row = new TableRow();
            boolean validSchema = TRUE;
            String errorMessage = "";
            int colSize =0;
            if(feed_name.get().equals("geo")) {
                colSize = geo_num_of_cols;
            }

            if (colSize != values.length) {
                validSchema = FALSE;
                errorMessage = "Column Index mismatch, Expected: " + colSize + ", Actual: " + values.length;
                logger.error("ERR_004_CDR_SCHEMA_MISMATCH");
            }
            else {
                /* Starting validation */
                if (!context.element().matches("AverageDownlinkThroughput(.*)")) {

                    // #1 averagedownlinkthroughput

                    AllRecordwithoutHeader.inc();

                    if(!util.floatFieldValidation(values[0])){
                        errorMessage += "Float value is invalid averagedownlinkthroughput: " + values[0] +"\n";
                        row.set("averagedownlinkthroughput",null);
                        validSchema = FALSE;
                    }
                    else if (util.nullValidation(values[0])){
                        row.set("averagedownlinkthroughput",null);
                    }
                    else {
                        row.set("averagedownlinkthroughput",values[0]);
                    }

                    // #2 averageuplinkthroughput
                    if(!util.floatFieldValidation(values[1])){
                        errorMessage += "Float value is invalid averageuplinkthroughput: " + values[1] +"\n";
                        row.set("averageuplinkthroughput",null);
                        validSchema = FALSE;

                    }else if (util.nullValidation(values[1])){
                        row.set("averageuplinkthroughput",null);
                    }else {
                        row.set("averageuplinkthroughput", values[1]);
                    }
                    // #3 endcellname
                    if(values[5].length() == 0 || values[5].matches("^\"{2}$")){

                        errorMessage += "Null value received for the core field  endcellname : " + values[5] +"\n";
                        row.set("endcellname",null);
                        validSchema = FALSE;
                    }
                    else if (util.nullValidation(values[5])) {
                        row.set("endcellname", null);
                    }
                    else {
                        row.set("endcellname",values[5]);
                    }
                    // #4 maskedImsi
                    if(values[8].length() == 0 || values[8].matches("^\"{2}$")){
                        errorMessage += "Null value received for the core field  maskedImsi : " + values[8] +"\n";
                        row.set("maskedimsi",null);
                        validSchema = FALSE;
                    }
                    else if (values[8].length()!= 15){
                        errorMessage += "maskedimsi field is INVALID or Length of maskedimsi field is not 15: " + values[8] +"\n";
                        row.set("maskedimsi",null);
                        validSchema = FALSE;
                    }
                    else if(!util.longFieldValidation(values[8])) {
                        errorMessage += "Integer value is invalid maskedimsi: " + values[8];
                        row.set("maskedimsi",null);
                        validSchema = FALSE;
                    }
                    else if (util.nullValidation(values[8])) {
                        row.set("maskedimsi", null);
                    }
                    else {
                        row.set("maskedimsi",values[8]);

                    }
                    // #5 minutesofuse
                    if(values[15].length() == 0 || values[15].matches("^\"{2}$") ){

                        errorMessage += "Null value received for the core field  minutesofuse : " + values[15] +"\n";
                        row.set("minutesofuse",null);
                        validSchema = FALSE;
                    }
                    else if(!util.floatFieldValidation(values[15])){
                        errorMessage += "Float value is invalid minutesofuse: " + values[15] +"\n";
                        row.set("minutesofuse",null);
                        validSchema = FALSE;

                    }
                    else if (util.nullValidation(values[15])) {
                        row.set("minutesofuse", null);
                    }
                    else {
                        row.set("minutesofuse",values[15]);
                    }

                    // #6 numberofconnections
                    if(!util.intFieldValidation(values[17])){
                        errorMessage += "Integer value is invalid numberofconnections: " + values[17] +"\n";
                        row.set("numberofconnections",null);
                        validSchema = FALSE;
                    }
                    else if (util.nullValidation(values[17])) {
                        row.set("numberofconnections", null);
                    }else{
                        row.set("numberofconnections",values[17]);
                    }
                    // #7 minutesofuse
                    if(values[18].length() == 0 || values[18].matches("^\"{2}$")){

                        errorMessage += "Null value received for the core field  pedestrianminutesofuse : " + values[18] +"\n";
                        row.set("pedestrianminutesofuse",null);
                        validSchema = FALSE;
                    }else if(!util.floatFieldValidation(values[18])){
                        errorMessage += "Float value is invalid pedestrianminutesofuse: " + values[18] +"\n";
                        row.set("pedestrianminutesofuse",null);
                        validSchema = FALSE;

                    }
                    else if (util.nullValidation(values[18])) {
                        row.set("pedestrianminutesofuse", null);
                    }else {
                        row.set("pedestrianminutesofuse",values[18]);
                    }

                    // #8 startcellname
                    if(values[24].length() == 0 || values[24].matches("^\"{2}$")){

                        errorMessage += "Null value received for the core field  startcellname : " + values[24] +"\n";
                        row.set("startcellname",null);
                        validSchema = FALSE;
                    }
                    else if (util.nullValidation(values[24])) {
                        row.set("startcellname", null);
                    }else {
                        row.set("startcellname",values[24]);
                    }
                    // #9 starttime
                    if(values[25].length() == 0 || values[25].matches("^\"{2}$")){
                        errorMessage += "Null value received for the core field  starttime : " + values[25] +"\n";
                        row.set("starttime",null);
                        validSchema = FALSE;
                    }
                    else if (util.nullValidation(values[25])) {
                        row.set("starttime", null);
                    }else {
                        row.set("starttime",values[25]);
                    }
                    // #10 stationaryminutesofuse
                    if(values[26].length() == 0 || values[26].matches("^\"{2}$")){

                        errorMessage += "Null value received for the core field  stationaryminutesofuse : " + values[26] +"\n";
                        row.set("stationaryminutesofuse",null);
                        validSchema = FALSE;
                    }else if(!util.floatFieldValidation(values[26])){
                        errorMessage += "Float value is invalid stationaryminutesofuse: " + values[26];
                        row.set("stationaryminutesofuse",null);
                        validSchema = FALSE;

                    }
                    else if (util.nullValidation(values[26])) {
                        row.set("stationaryminutesofuse", null);
                    }
                    else {
                        row.set("stationaryminutesofuse",values[26]);
                    }
                    // #11 sv
                   if (util.nullValidation(values[27])) {
                        row.set("sv", null);
                    }else {
                        row.set("sv",values[27]);
                    }
                    // #12 tac
                    if((values[28].length() == 0 || values[28].matches("^\"{2}$") ) && values[8].length()!= 15 ){

                        errorMessage += "Null value received for the core field  tac : " + values[28] +"\n";
                        row.set("tac",null);
                        validSchema = FALSE;
                    }
                    else if (util.nullValidation(values[28])) {
                        row.set("tac", null);
                    }else {
                        row.set("tac",values[28]);
                    }

                    // #13 totaldownlinkdataduration
                    if(!util.floatFieldValidation(values[32])){
                        errorMessage += "Float value is invalid totaldownlinkdataduration: " + values[32] +"\n";
                        row.set("totaldownlinkdataduration",null);
                        validSchema = FALSE;

                    }else if (util.nullValidation(values[32])) {
                        row.set("totaldownlinkdataduration", null);
                    }else {
                        row.set("totaldownlinkdataduration", values[32]);
                    }

                    // #14 totaldownlinkvolume
                    if(!util.intFieldValidation(values[33])){

                        errorMessage += "Integer value is invalid totaldownlinkvolume: " + values[33] +"\n";
                        row.set("totaldownlinkvolume",null);
                        validSchema = FALSE;

                    }else if (util.nullValidation(values[33])) {
                        row.set("totaldownlinkvolume", null);
                    }else {
                        row.set("totaldownlinkvolume",values[33]);
                    }

                    // #15 totaldownlinkvolume
                    if(!util.floatFieldValidation(values[37])){
                        errorMessage += "Float value is invalid totaluplinkdataduration: " + values[37] +"\n";
                        row.set("totaluplinkdataduration",null);
                        validSchema = FALSE;

                    }else if (util.nullValidation(values[37])) {
                        row.set("totaluplinkdataduration", null);
                    }else {
                        row.set("totaluplinkdataduration", values[37]);
                    }
                    // #16 totaluplinkvolume
                    if(!util.intFieldValidation(values[38])){

                        errorMessage += "Integer value is invalid totaluplinkvolume: " + values[38] +"\n";
                        row.set("totaluplinkvolume",null);
                        validSchema = FALSE;

                    }else if (util.nullValidation(values[38])) {
                        row.set("totaluplinkvolume", null);
                    }else {
                        row.set("totaluplinkvolume",values[38]);
                    }


                    // #17 vehicularminutesofuse
                    if(values[39].length() == 0 || values[39].matches("^\"{2}$")){

                        errorMessage += "Null value received for the core field  vehicularminutesofuse : " + values[39] +"\n";
                        row.set("vehicularminutesofuse",null);
                        validSchema = FALSE;
                    }else if(!util.floatFieldValidation(values[39])){
                        errorMessage += "Float value is invalid vehicularminutesofuse: " + values[39] +"\n";
                        row.set("vehicularminutesofuse",null);
                        validSchema = FALSE;

                    }else if (util.nullValidation(values[39])) {
                        row.set("vehicularminutesofuse", null);
                    }else {
                        row.set("vehicularminutesofuse",values[39]);
                    }
                    // #18 voiceminutesofuse
                    if(!util.floatFieldValidation(values[40])){
                        errorMessage += "Float value is invalid voiceminutesofuse: " + values[40] +"\n";
                        row.set("voiceminutesofuse",null);
                        validSchema = FALSE;

                    }else if (util.nullValidation(values[40])) {
                        row.set("voiceminutesofuse", null);
                    }else{
                        row.set("voiceminutesofuse",values[40]);
                    }

                    // #19 xbin
                    if(values[44].length() == 0 || values[44].matches("^\"{2}$")){

                        errorMessage += "Null value received for the core field  xbin : " + values[44] +"\n";
                        row.set("xbin",null);
                        validSchema = FALSE;
                    }
                    else if (util.nullValidation(values[44])) {
                        row.set("xbin", null);
                    }else {
                        row.set("xbin",values[44]);
                    }

                    // #20 ybin
                    if(values[45].length() == 0 || values[45].matches("^\"{2}$")){

                        errorMessage += "Null value received for the core field  ybin : " + values[45] +"\n";
                        row.set("ybin",null);
                        validSchema = FALSE;
                    }else if (util.nullValidation(values[45])) {
                        row.set("ybin", null);
                    }else {
                        row.set("ybin",values[45]);
                    }

                    // #21 indoorminutesofuse
                    if(values[46].length() == 0 || values[46].matches("^\"{2}$")){

                        errorMessage += "Null value received for the core field  indoorminutesofuse : " + values[46] +"\n";
                        row.set("indoorminutesofuse",null);
                        validSchema = FALSE;
                    }else if(!util.floatFieldValidation(values[46])){
                        errorMessage += "Float value is invalid indoorminutesofuse: " + values[46] +"\n";
                        row.set("indoorminutesofuse",null);
                        validSchema = FALSE;

                    }else if (util.nullValidation(values[46])) {
                        row.set("indoorminutesofuse", null);
                    }else {
                        row.set("indoorminutesofuse",values[46]);
                    }

                    // #22 outdoorminutesofuse
                    if(values[47].length() == 0 || values[47].matches("^\"{2}$")){

                        errorMessage += "Null value received for the core field  outdoorminutesofuse : " + values[47] +"\n";
                        row.set("outdoorminutesofuse",null);
                        validSchema = FALSE;
                    }else if(!util.floatFieldValidation(values[47])){
                        errorMessage += "Float value is invalid outdoorminutesofuse: " + values[47] +"\n";
                        row.set("outdoorminutesofuse",null);
                        validSchema = FALSE;

                    }else if (util.nullValidation(values[47])) {
                        row.set("outdoorminutesofuse", null);
                    }else {
                        row.set("outdoorminutesofuse",values[47]);
                    }

                    if (validSchema) {
                        validRecords.inc();
                        row.set("batch_num",batch_num.get());
                        out.get(validDataTag).output(row);
                    }
                    else {
                        errorRecord.inc();
                        row.set("batch_num", batch_num.get());
                        row.set("error_reason", errorMessage);
                        row.set("load_datetime", util.getCurrentDateTime());
                        out.get(invalidDataTag).output(row);
                    }

                }

                /* End Validation */

            }
        }
        catch (Exception e) {
            logger.error("ERR_001_CDR_DF_FAILURE");
            logger.error("Error when parsing element to schema");
            logger.error(e.getMessage());
        }
    }
}
