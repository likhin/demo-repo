package com.bt.gcp.pipelines;
import static com.bt.gcp.constants.Constants.geo_COLUMNS;
import static com.bt.gcp.constants.Constants.geo_D_TYPES;
import com.bt.gcp.options.ViaviOptions;
import com.bt.gcp.transform.ExtractAndTransform;
import com.bt.gcp.util.SchemaUtil;
import com.google.api.services.bigquery.model.TableRow;
import com.google.api.services.bigquery.model.TableSchema;
import org.apache.beam.runners.dataflow.DataflowRunner;
import org.apache.beam.runners.direct.DirectRunner;
import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.io.TextIO;
import org.apache.beam.sdk.io.gcp.bigquery.BigQueryIO;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.sdk.values.PCollectionTuple;
import org.apache.beam.sdk.values.TupleTag;
import org.apache.beam.sdk.values.TupleTagList;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.ArrayList;
import java.util.Arrays;

public class ViaviPipeline {
    private static final long serialVersionUID = 1L;
    private static final Logger logger = LoggerFactory.getLogger(ViaviPipeline.class);

    public static void main(String[] args) {
        PipelineOptionsFactory.register(ViaviOptions.class);
        ViaviOptions options =PipelineOptionsFactory.fromArgs(args).withValidation().create().as(ViaviOptions.class);
        SchemaUtil sutil = new SchemaUtil();
        //options.setRunner(DirectRunner.class);
        options.setRunner(DataflowRunner.class);
        Pipeline p = Pipeline.create(options);

        final TupleTag<TableRow> validDataTag =  new TupleTag<TableRow>("validDataTag"){};
        final TupleTag<TableRow> invalidDataTag =  new TupleTag<TableRow>("invalidDataTag"){};

        TableSchema schema_geo = sutil.getSchema_geo();
        TableSchema schema_geo_corr = sutil.getSchema_geo_corr();


        PCollectionTuple dataTuple= p.apply("ReadDataFromGCS", TextIO.read().from(options.getSource()))
                .apply("ValidateSchema",ParDo.of(new ExtractAndTransform(options.getBatchNum(),options.getFeedname())).withOutputTags(validDataTag, TupleTagList.of(invalidDataTag)));

        PCollection<TableRow> cleansedPc= dataTuple.get("validDataTag");
        PCollection<TableRow> errorPc= dataTuple.get("invalidDataTag");

        cleansedPc.apply("WriteToBigQuery", BigQueryIO.writeTableRows().to(options.getBqTableName())
                .withSchema(schema_geo)
                .withCreateDisposition(BigQueryIO.Write.CreateDisposition.CREATE_IF_NEEDED)
                .withWriteDisposition(BigQueryIO.Write.WriteDisposition.WRITE_APPEND));

        errorPc.apply("WriteToBigQueryError", BigQueryIO.writeTableRows().to(options.getBqErrorTableName())
                .withSchema(schema_geo_corr)
                .withCreateDisposition(BigQueryIO.Write.CreateDisposition.CREATE_IF_NEEDED)
                .withWriteDisposition(BigQueryIO.Write.WriteDisposition.WRITE_APPEND));

        p.run();
    }
}
