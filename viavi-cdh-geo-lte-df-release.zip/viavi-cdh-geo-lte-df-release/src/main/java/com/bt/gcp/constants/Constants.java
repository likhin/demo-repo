package com.bt.gcp.constants;

import java.util.ArrayList;
import java.util.Arrays;

public class Constants {

    public static final String geo_COLUMNS  = "averagedownlinkthroughput,averageuplinkthroughput,endcellname,maskedimsi,minutesofuse," +
            "numberofconnections,pedestrianminutesofuse,startcellname,starttime,stationaryminutesofuse,sv,tac,totaldownlinkdataduration," +
            "totaldownlinkvolume,totaluplinkdataduration,totaluplinkvolume,vehicularminutesofuse," +
            "voiceminutesofuse,xbin,ybin,indoorminutesofuse,outdoorminutesofuse";

    public static final String geo_D_TYPES  = "FLOAT,FLOAT,STRING,INTEGER,FLOAT,INTEGER,FLOAT,STRING," +
            "TIMESTAMP,FLOAT,STRING,STRING,FLOAT,INTEGER,FLOAT,INTEGER,FLOAT,FLOAT,STRING,STRING,FLOAT,FLOAT"
            ;

    public static final ArrayList<Integer> geo_req_field_l = new ArrayList<>(Arrays.asList(5,8,15,18,24,25,26,28,39,44,45,46,47));

    public static final ArrayList<Integer> geo_skip_fields = new ArrayList<>(Arrays.asList(2,3,4,6,7,9,10,11,12,13,14,16,19,20,21,22,23,29,30,
            31,34,35,36,41,42,43));

    public static final int geo_num_of_cols = 48;
}
